package com.watermark.model;

public enum TopicType {

    SCIENCE, BUSINESS, MEDIA;

}
