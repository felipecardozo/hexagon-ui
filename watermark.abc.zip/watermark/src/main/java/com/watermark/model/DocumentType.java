package com.watermark.model;

public enum DocumentType {

    BOOK, JOURNAL;

}
