package com.watermark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WatermarkApplication {


    // https://github.com/BatyrMalik/watermarkService/
    // https://github.com/cthies/watermarks
    // https://github.com/lquintela/watermark
    // https://github.com/vitorreis/watermark/

    public static void main(String[] args) {
        SpringApplication.run(WatermarkApplication.class, args);
    }
}
