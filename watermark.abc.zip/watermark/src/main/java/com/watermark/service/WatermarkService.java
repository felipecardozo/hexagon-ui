package com.watermark.service;

import java.util.List;

import com.watermark.model.Document;

public interface WatermarkService {

    public List<Document> getAllDocumentsByContent(String contentDocument);



}
