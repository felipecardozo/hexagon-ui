package com.slapp.util;

import javax.inject.Inject;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.slapp.repository.DeviceItemRepository;
import com.slapp.repository.DeviceListRepository;

@Component
public class DatabaseMock implements CommandLineRunner {

    private DeviceListRepository deviceListRepository;

    private DeviceItemRepository deviceItemRepository;

    @Inject
    public DatabaseMock(DeviceListRepository deviceListRepository, DeviceItemRepository deviceItemRepository) {
        this.deviceItemRepository = deviceItemRepository;
        this.deviceItemRepository = deviceItemRepository;
    }


    @Override
    public void run(String... strings) throws Exception {
        // DeviceList list = new DeviceList("Groceries");
        // deviceListRepository.save(list);
        // deviceItemRepository.save(new DeviceItem(1L, "item1", false, "", list));
    }
}
