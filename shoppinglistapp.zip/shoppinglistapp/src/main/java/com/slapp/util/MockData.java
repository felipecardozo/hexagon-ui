package com.slapp.util;

import java.util.ArrayList;
import java.util.List;

import com.slapp.domain.DeviceItem;
import com.slapp.domain.DeviceList;

public class MockData {

    public static List<DeviceList> createMockList() {
        List<DeviceList> data = new ArrayList<>();
        return data;
    }

    public static List<DeviceItem> createDeviceItems(Long id, String itemName) {
        List<DeviceItem> items = new ArrayList<>();
        return items;
    }

}
