package com.slapp.service;

import org.springframework.stereotype.Service;

@Service
public class ShoppingService {

}
