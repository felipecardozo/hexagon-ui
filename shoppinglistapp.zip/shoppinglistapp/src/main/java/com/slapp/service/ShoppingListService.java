package com.slapp.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.slapp.domain.DeviceList;
import com.slapp.repository.DeviceItemRepository;
import com.slapp.repository.DeviceListRepository;

@Service
public class ShoppingListService {

    private DeviceItemRepository itemRepository;
    private DeviceListRepository deviceListRepository;

    @Inject
    public ShoppingListService(DeviceItemRepository itemRepository, DeviceListRepository deviceListRepository) {
        this.itemRepository = itemRepository;
        this.deviceListRepository = deviceListRepository;
    }

    public DeviceList createDeviceList(String listName) {
        return deviceListRepository.save(new DeviceList(listName));
    }

    public List<DeviceList> getAllDeviceList() {
        // return StreamSupport.stream(deviceListRepository.findAll().spliterator(),
        // false).collect(Collectors.toList());
        return deviceListRepository.findAll();
    }

}
