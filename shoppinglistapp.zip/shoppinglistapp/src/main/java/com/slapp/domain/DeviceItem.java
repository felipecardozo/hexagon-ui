package com.slapp.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
public class DeviceItem {

    @Getter
    @Setter
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long idItem;
    @Getter
    @Setter
    private String itemName;
    @Getter
    @Setter
    private Boolean isMarkedAsChecked;
    @Getter
    @Setter
    private String quantityDescrription;
    @Getter
    @Setter
    @ManyToOne
    private DeviceList deviceList;

}
