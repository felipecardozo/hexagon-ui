package com.slapp.rest;

import java.util.List;

import javax.inject.Inject;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.slapp.domain.DeviceList;
import com.slapp.service.ShoppingListService;

@RestController
public class ShoppingContorller {

    private ShoppingListService shoppingListService;

    @Inject
    public ShoppingContorller(ShoppingListService shoppingListService) {
        this.shoppingListService = shoppingListService;
    }

    @GetMapping("/list")
    public String demo() {
        return "demo";
    }

    @GetMapping()
    public List<DeviceList> getAllDeviceList() {
        return shoppingListService.getAllDeviceList();
    }

    @PostMapping()
    public DeviceList addDeviceList(@RequestBody String listName) {
        return shoppingListService.createDeviceList(listName);
    }

}
