package com.slapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.slapp.domain.DeviceList;

@Repository
public interface DeviceListRepository extends JpaRepository<DeviceList, Long> {

}
