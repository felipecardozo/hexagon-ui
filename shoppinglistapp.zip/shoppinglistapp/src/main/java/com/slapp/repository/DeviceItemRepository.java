package com.slapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.slapp.domain.DeviceItem;

@Repository
public interface DeviceItemRepository extends JpaRepository<DeviceItem, Long> {

}
