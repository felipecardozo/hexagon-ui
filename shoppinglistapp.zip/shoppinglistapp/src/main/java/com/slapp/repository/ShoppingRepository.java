package com.slapp.repository;

import java.util.ArrayList;
import java.util.List;

import com.slapp.domain.DeviceList;
import com.slapp.util.MockData;

// @Repository
public class ShoppingRepository {

    private List<DeviceList> list;

    public ShoppingRepository() {
        if (list.isEmpty()) {
            MockData.createMockList();
        }
    }

    public void addDeviceList(DeviceList devices) throws IllegalArgumentException {
        if (devices.getIdOnDevice() == null) {
            throw new IllegalArgumentException("error adding new device, id is null");
        }
        this.list.add(devices);
    }

    public DeviceList getDeviceList(Long id) {
        for (DeviceList dev : list) {
            if (dev.getIdOnDevice() == id) {
                return dev;
            }
        }
        return null;
    }

    public DeviceList updateDeviceList(DeviceList device) throws IllegalArgumentException {
        if (device.getIdOnDevice() == null) {
            throw new IllegalArgumentException("error updating device, id is null");
        }
        for (DeviceList dev : list) {
            if (dev.getIdOnDevice() == device.getIdOnDevice()) {
                dev.setListName(dev.getListName());
                return dev;
            }
        }
        return null;
    }

    public DeviceList findDeviceListById(Long idDeviceList) {
        if (idDeviceList == null) {
            throw new IllegalArgumentException("error finding device, id is null");
        }
        for (DeviceList dev : list) {
            if (dev.getIdOnDevice() == idDeviceList) {
                return dev;
            }
        }
        return null;
    }

    public void deleteDevice(Long idDeviceList) {
        if (idDeviceList == null) {
            throw new IllegalArgumentException("error deleting device, id is null");
        }
        List<DeviceList> toDelete = new ArrayList<>();
        DeviceList dev = findDeviceListById(idDeviceList);
        if (dev != null) {
            toDelete.add(dev);
        }
        list.removeAll(toDelete);
    }

    public int count() {
        return list.size();
    }

}
